'use strict';
(self.webpackChunkus_sams_new = self.webpackChunkus_sams_new || []).push([
  [781],
  {
    781: (e, n, t) => {
      t.r(n),
        t.d(n, {
          default: () => w,
        });
      var a = t(294),
        c = t(788);
      const r = t.p + 'pngwing.com-2.png';
      var s, i, l;
      function u(e, n) {
        return (
          n || (n = e.slice(0)),
          Object.freeze(
            Object.defineProperties(e, {
              raw: {
                value: Object.freeze(n),
              },
            }),
          )
        );
      }
      var d = c.ZP.div(
          s ||
            (s = u([
              '\n    width: 100%;\n    display: flex;\n    justify-content: center;\n    margin-bottom: 0.5rem;\n',
            ])),
        ),
        f = c.ZP.div(
          i ||
            (i = u([
              '\n    width: 80%;\n    @media only screen and (max-width: 600px) {\n        width: 100%;\n    }\n',
            ])),
        ),
        m = c.ZP.img(l || (l = u(['\n    width: 100%;\n'])));
      const w = function () {
        return a.createElement(
          d,
          null,
          a.createElement(
            f,
            null,
            a.createElement(m, {
              src: r,
            }),
          ),
        );
      };
    },
  },
]);
